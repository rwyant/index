//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Rob Wyant on 1/12/16.
//  Copyright © 2016 Yapper. All rights reserved.
//

import Foundation

protocol CalculatorBrainDelegate {
    func updateDisplay(returnValue: String)
}

class CalculatorBrain {
    var delegate: CalculatorBrainDelegate?
    let defaults = NSUserDefaults.standardUserDefaults()
    var isTyping = false
    var isError = false
    var firstNumber = 0.0
    var secondNumber = 0.0
    var operand = ""
    var displayText = ""
    
    func buttonPressed(senderTitle: String) {
        setupDefaults()
        
        switch senderTitle {
        case "=" : equals(senderTitle);
        case "/", "x", "-", "+" : operate(senderTitle)
        case "+/-" : swapSigns();
        case "c" : clearButton();
        case "%" : percentButton();
        case "." : decimal(senderTitle);
        default: appendDigit(senderTitle)
        }
    }
    
    //MARK: Update Display method
    
    func appendDigit(digit: String) {
        defaults.setBool(false, forKey: "isError")
        if isTyping {
            delegate?.updateDisplay("\(displayText)\(digit)")
        } else {
            delegate?.updateDisplay("\(digit)")
            defaults.setBool(true, forKey: "isTyping")
        }
    }

    //MARK: Calculate method
    
    func calculateEquation() {
        defaults.setBool(false, forKey: "isTyping")

        var result = 0.0
        let numOfPlaces = 6.0
        let multiplier = pow(10,numOfPlaces)
        
        switch operand {
        case "x" : result = firstNumber * secondNumber
        case "/" :
            if secondNumber == 0 {
                handleError()
                return
            } else {
                result = firstNumber / secondNumber
            }
            
        case "+" : result = firstNumber + secondNumber
        case "-" : result = firstNumber - secondNumber
        default : break
        }
        
        if result >= 999999999999 {
            handleError()
            return
        }
        
        result = round(result * multiplier) / multiplier
        delegate?.updateDisplay("\(result)")
        defaults.setDouble(result, forKey: "firstNumber")
    }
    
    //MARK: Operator Methods
    
    func equals(senderTitle: String) {
        if !isError {
            if operand != "=" {
                secondNumber = displayValue
                defaults.setDouble(secondNumber, forKey: "secondNumber")
                calculateEquation()
                defaults.setObject(senderTitle, forKey: "operand")
            }
        }
    }
    
    func operate(senderTitle: String) {
        defaults.setBool(false, forKey: "isTyping")
        if !isError {
            if operand == "" || operand == "=" {
                firstNumber = displayValue
                defaults.setDouble(firstNumber, forKey: "firstNumber")
                defaults.setBool(false, forKey: "isTyping")
                defaults.setObject(senderTitle, forKey: "operand")
            } else {
                isTyping = false
                secondNumber = displayValue
                defaults.setDouble(secondNumber, forKey: "secondNumber")
                calculateEquation()
                operand = senderTitle
            }
        }
    }
    
    func clearButton() {
        defaults.setObject("0", forKey: "displayText")
        delegate?.updateDisplay("0")
        isTyping = false
        if !isTyping {
            resetCalc()
        }
    }
    
    func resetCalc() {
        defaults.setDouble(0.0, forKey: "firstNumber")
        defaults.setDouble(0.0, forKey: "secondNumber")
        defaults.setObject("", forKey: "operand")
    }
    
    func swapSigns() {
        if !isError {
            if displayText != "0" {
                defaults.setObject("\(displayValue * -1)", forKey: "displayText")
                delegate?.updateDisplay("\(displayValue * -1)")
            }
        }
    }
    
    func percentButton() {
        if !isError {
            if displayText != "0" {
                defaults.setObject("\(displayValue / 100)", forKey: "displayText")
                delegate?.updateDisplay("\(displayValue / 100)")
            }
        }
    }
    
    func decimal(senderTitle: String) {
        if !displayText.characters.contains(".") {
            appendDigit(senderTitle)
        }
    }
    
    func handleError() {
        delegate?.updateDisplay("Error")
        defaults.setBool(true, forKey: "isError")
        resetCalc()
    }
    
    var displayValue: Double {
        get {
            return NSNumberFormatter().numberFromString(displayText)!.doubleValue
        } set {
            defaults.setObject("\(newValue)", forKey: "displayText")
            delegate?.updateDisplay("\(newValue)")
        }
    }
    
    //MARK: Setup Defaults
    
    func initialSetupOfUserDefaults() {
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject("", forKey: "operand")
        defaults.setDouble(0.0, forKey: "firstNumber")
        defaults.setDouble(0.0, forKey: "secondNumber")
        defaults.setBool(false, forKey: "isTyping")
        defaults.setBool(false, forKey: "isError")
        defaults.synchronize()
    }
    
    func setupDefaults() {
        isTyping = defaults.boolForKey("isTyping")
        isError = defaults.boolForKey("isError")
        firstNumber = defaults.doubleForKey("firstNumber")
        secondNumber = defaults.doubleForKey("secondNumber")
        if let operandDefault = defaults.objectForKey("operand") as? String {
            operand = operandDefault
        }
        if let displayTextDefault = defaults.objectForKey("displayText") as? String {
            displayText = displayTextDefault
        }
    }
}