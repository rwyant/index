//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Rob Wyant on 1/12/16.
//  Copyright © 2016 Yapper. All rights reserved.
//

import Foundation

protocol CalculatorBrainDelegate {
    func updateDisplay(returnValue: String)
}

class CalculatorBrain {
    var delegate: CalculatorBrainDelegate?
    let defaults = NSUserDefaults.standardUserDefaults()
    var isTyping = false
    var isError = false
    var firstNumber = 0.0
    var secondNumber = 0.0
    var operand = ""
    var displayText = ""
    
    func buttonPressed(senderTitle: String) {
        setupDefaultsInCalculatorBrain()
        
        switch senderTitle {
        case "=" : equals(senderTitle);
        case "/", "x", "-", "+" : operate(senderTitle)
        case "+/-" : swapSigns();
        case "c" : clearButton();
        case "%" : percentButton();
        case "." : decimal(senderTitle);
        default: appendDigit(senderTitle)
        }
    }
    
    //MARK: Update Display method
    
    func appendDigit(digit: String) {
        updateUserDefaults(false, forKey: "isError")
        if isTyping {
            delegate?.updateDisplay("\(displayText)\(digit)")
        } else {
            delegate?.updateDisplay("\(digit)")
            updateUserDefaults(true, forKey: "isTyping")
        }
    }

    //MARK: Calculate method
    
    func calculateEquation() {
        updateUserDefaults(false, forKey: "isTyping")

        var result = 0.0
        let numOfPlaces = 6.0
        let multiplier = pow(10,numOfPlaces)
        
        switch operand {
        case "x" : result = firstNumber * secondNumber
        case "/" :
            if secondNumber == 0 {
                handleError()
                return
            } else {
                result = firstNumber / secondNumber
            }
            
        case "+" : result = firstNumber + secondNumber
        case "-" : result = firstNumber - secondNumber
        default : break
        }
        
        if result >= 999999999999 {
            handleError()
            return
        }
        
        result = round(result * multiplier) / multiplier
        delegate?.updateDisplay("\(result)")
        updateUserDefaults(result, forKey: "firstNumber")
    }
    
    //MARK: Operator Methods
    
    func equals(senderTitle: String) {
        if !isError {
            if operand != "=" {
                secondNumber = displayValue
                updateUserDefaults(secondNumber, forKey: "secondNumber")
                calculateEquation()
                updateUserDefaults(senderTitle, forKey: "operand")
            }
        }
    }
    
    func operate(senderTitle: String) {
        updateUserDefaults(false, forKey: "isTyping")
        if !isError {
            if operand == "" || operand == "=" {
                firstNumber = displayValue
                updateUserDefaults(firstNumber, forKey: "firstNumber")
                updateUserDefaults(false, forKey: "isTyping")
                updateUserDefaults(senderTitle, forKey: "operand")
            } else {
                isTyping = false
                secondNumber = displayValue
                updateUserDefaults(secondNumber, forKey: "secondNumber")
                calculateEquation()
                operand = senderTitle
            }
        }
    }
    
    func clearButton() {
        updateUserDefaults("0", forKey: "displayText")
        delegate?.updateDisplay("0")
        isTyping = false
        if !isTyping {
            resetCalc()
        }
    }
    
    func resetCalc() {
        updateUserDefaults(0.0, forKey: "firstNumber")
        updateUserDefaults(0.0, forKey: "secondNumber")
        updateUserDefaults("", forKey: "operand")
    }
    
    func swapSigns() {
        if !isError {
            if displayText != "0" {
                updateUserDefaults("\(displayValue * -1)", forKey: "displayText")
                delegate?.updateDisplay("\(displayValue * -1)")
            }
        }
    }
    
    func percentButton() {
        if !isError {
            if displayText != "0" {
                updateUserDefaults("\(displayValue / 100)", forKey: "displayText")
                delegate?.updateDisplay("\(displayValue / 100)")
            }
        }
    }
    
    func decimal(senderTitle: String) {
        if !displayText.characters.contains(".") {
            appendDigit(senderTitle)
        }
    }
    
    func handleError() {
        delegate?.updateDisplay("Error")
        updateUserDefaults(true, forKey: "isError")
        resetCalc()
    }
    
    var displayValue: Double {
        get {
            return NSNumberFormatter().numberFromString(displayText)!.doubleValue
        } set {
            updateUserDefaults("\(newValue)", forKey: "displayText")
            delegate?.updateDisplay("\(newValue)")
        }
    }
    
    //MARK: User Defaults
    
    func initialSetupOfUserDefaults() {
        updateUserDefaults("", forKey: "operand")
        updateUserDefaults(0.0, forKey: "firstNumber")
        updateUserDefaults(0.0, forKey: "secondNumber")
        updateUserDefaults(false, forKey: "isTyping")
        updateUserDefaults(false, forKey: "isError")
    }
    
    func setupDefaultsInCalculatorBrain() {
        isTyping = defaults.boolForKey("isTyping")
        isError = defaults.boolForKey("isError")
        firstNumber = defaults.doubleForKey("firstNumber")
        secondNumber = defaults.doubleForKey("secondNumber")
        if let operandDefault = defaults.objectForKey("operand") as? String {
            operand = operandDefault
        }
        if let displayTextDefault = defaults.objectForKey("displayText") as? String {
            displayText = displayTextDefault
        }
    }
    
    func updateUserDefaults(value: AnyObject, forKey: String) {
        defaults.setObject(value, forKey: forKey)
        defaults.synchronize()
    }
}