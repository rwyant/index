//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Rob Wyant on 1/12/16.
//  Copyright © 2016 Yapper. All rights reserved.
//

import Foundation

protocol CalculatorBrainDelegate {
    func updateDisplay(returnValue: String)
}

class CalculatorBrain {
    var delegate: CalculatorBrainDelegate?
    
    var isTyping = false
    var isError = false
    var firstNumber = 0.0
    var secondNumber = 0.0
    var operand = ""
    var displayText = "0"
    
    func buttonPressed(senderTitle: String, displayText: String) {
        self.displayText = displayText
        
        switch senderTitle {
        case "=" : equals(senderTitle);
        case "/", "x", "-", "+" : operate(senderTitle)
        case "+/-" : swapSigns();
        case "c" : clearButton();
        case "%" : percentButton();
        case "." : decimal(senderTitle);
        default: appendDigit(senderTitle)
        }
    }
    
    //MARK: Update Display method
    
    private func appendDigit(digit: String) {
        isError = false
        if isTyping {
            delegate?.updateDisplay("\(displayText)\(digit)")
        } else {
            delegate?.updateDisplay("\(digit)")
            isTyping = true
        }
    }

    //MARK: Calculate method
    
    private func calculateEquation() {
        isTyping = false

        var result = 0.0
        let numOfPlaces = 6.0
        let multiplier = pow(10,numOfPlaces)
        
        switch operand {
        case "x" : result = firstNumber * secondNumber
        case "/" :
            if secondNumber == 0 {
                handleError()
                return
            } else {
                result = firstNumber / secondNumber
            }
            
        case "+" : result = firstNumber + secondNumber
        case "-" : result = firstNumber - secondNumber
        default : break
        }
        
        if result >= 999999999999 {
            handleError()
            return
        }
        
        result = round(result * multiplier) / multiplier
        delegate?.updateDisplay("\(result)")
        firstNumber = result
    }
    
    //MARK: Operator Methods
    
    private func equals(senderTitle: String) {
        if !isError {
            if operand != "=" {
                secondNumber = displayValue
                calculateEquation()
                operand = senderTitle
            }
        }
    }
    
    private func operate(senderTitle: String) {
        isTyping = false
        if !isError {
            if operand == "" || operand == "=" {
                firstNumber = displayValue
                isTyping = false
                operand = senderTitle
            } else {
                isTyping = false
                secondNumber = displayValue
                calculateEquation()
                operand = senderTitle
            }
        }
    }
    
    private func clearButton() {
        displayText = "0"
        delegate?.updateDisplay("0")
        isTyping = false
        if !isTyping {
            resetCalc()
        }
    }
    
    private func resetCalc() {
        firstNumber = 0.0
        secondNumber = 0.0
        operand = ""
    }
    
    private func swapSigns() {
        if !isError {
            if displayText != "0" {
                displayText = "\(displayValue * -1)"
                delegate?.updateDisplay("\(displayText)")
            }
        }
    }
    
    private func percentButton() {
        if !isError {
            if displayText != "0" {
                displayText = "\(displayValue / 100)"
                delegate?.updateDisplay("\(displayText)")

            }
        }
    }
    
    private func decimal(senderTitle: String) {
        if !displayText.characters.contains(".") {
            appendDigit(senderTitle)
        }
    }
    
    private func handleError() {
        delegate?.updateDisplay("Error")
        isError = true
        resetCalc()
    }
    
    private var displayValue: Double {
        get {
            return NSNumberFormatter().numberFromString(displayText)!.doubleValue
        } set {
            displayText = "\(newValue)"
            delegate?.updateDisplay("\(newValue)")
        }
    }
}