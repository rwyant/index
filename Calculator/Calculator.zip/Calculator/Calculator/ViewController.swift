//
//  ViewController.swift
//  Calculator
//
//  Created by Rob Wyant on 1/12/16.
//  Copyright © 2016 Yapper. All rights reserved.
//

import UIKit

class ViewController: UIViewController, CalculatorBrainDelegate {
    
    @IBOutlet weak var display: UILabel!
    
    let calculatorBrain = CalculatorBrain()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        calculatorBrain.initialSetupOfUserDefaults()
        calculatorBrain.delegate = self
    }
    
    @IBAction func buttonPressed(sender: UIButton) {
        if let senderTitle = sender.currentTitle, let displayText = display.text {
            NSUserDefaults.standardUserDefaults().setObject(displayText, forKey: "displayText")
            calculatorBrain.buttonPressed(senderTitle)
        }
    }
    
    //MARK: Protocol Method
    
    func updateDisplay(returnValue: String) {
        display.text = returnValue
    }
}

