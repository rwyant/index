//
//  Chapters.swift
//  Cereal The Game
//
//  Created by Rob Wyant on 3/7/15.
//  Copyright (c) 2015 Rob Wyant. All rights reserved.
//

import Foundation

struct Chapters {
    var chapter:String
    var chapterNumber: String
    var founded:String
    var isInternational:Bool
    var read:Bool
}