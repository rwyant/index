//
//  Bridging-Header.h
//  SwiftGuild
//
//  Created by Rob Wyant on 8/19/15.
//  Copyright (c) 2015 General Assembly. All rights reserved.
//

#ifndef SwiftGuild_Bridging_Header_h
#define SwiftGuild_Bridging_Header_h


#endif
