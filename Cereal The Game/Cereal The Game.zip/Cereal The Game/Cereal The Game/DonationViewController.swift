//
//  DonationViewController.swift
//  Cereal The Game
//
//  Created by Rob Wyant on 3/22/15.
//  Copyright (c) 2015 Rob Wyant. All rights reserved.
//

import UIKit
import StoreKit

class DonationViewController: UIViewController, SKProductsRequestDelegate, SKPaymentTransactionObserver {
    
    @IBOutlet weak var tier1Outlet: UIButton!
    @IBOutlet weak var tier2Outlet: UIButton!
    @IBOutlet weak var tier3Outlet: UIButton!
    @IBOutlet weak var tier4Outlet: UIButton!
    
    var list = [SKProduct]()
    var p = SKProduct()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tier1Outlet.enabled = false
        tier2Outlet.enabled = false
        tier3Outlet.enabled = false
        tier4Outlet.enabled = false
        
        //Set IAP
        if(SKPaymentQueue.canMakePayments()) {
            println("IAP is enabled, loading")
            var productID:NSSet = NSSet(objects: "com.surpriseindustries.robyn.tier1", "com.surpriseindustries.robyn.tier2", "com.surpriseindustries.robyn.tier3", "com.surpriseindustries.robyn.tier4")
            var requests: SKProductsRequest = SKProductsRequest(productIdentifiers: productID as Set<NSObject>)
            requests.delegate = self
            requests.start()
        } else {
            println("please enable IAPs")
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func tier1Button(sender: UIButton) {
        for product in list {
            var prodID = product.productIdentifier
            if(prodID == "com.surpriseindustries.robyn.tier1") {
                p = product
                buyProduct()
                break
            }
        }
    }
    
    @IBAction func tier2Button(sender: UIButton) {
        for product in list {
            var prodID = product.productIdentifier
            if(prodID == "com.surpriseindustries.robyn.tier2") {
                p = product
                buyProduct()
                break
            }
        }
    }
    
    @IBAction func tier3Button(sender: UIButton) {
        for product in list {
            var prodID = product.productIdentifier
            if(prodID == "com.surpriseindustries.robyn.tier3") {
                p = product
                buyProduct()
                break
            }
        }
    }
    
    @IBAction func tier4Button(sender: UIButton) {
        for product in list {
            var prodID = product.productIdentifier
            if(prodID == "com.surpriseindustries.robyn.tier4") {
                p = product
                buyProduct()
                break
            }
        }
    }
    
    func displayAlert(#title: String, message: String, buttonText: String) {
        let alert = UIAlertView()
        alert.title = title
        alert.message = message
        // We can add other buttons
        alert.addButtonWithTitle(buttonText)
        // We call the show() method once we have all of our alert properties set
        alert.show()
    }
    
    func donateBitches() {
        displayAlert(title: "Donation Box", message: "Thank you for your generosity! We hope you enjoyed your experience in Cereal The Game. Please tell your friends about how much fun you had!", buttonText: "Thanks for your support")
    }
    
    @IBAction func restorePurchasesButton(sender: UIButton) {
        SKPaymentQueue.defaultQueue().addTransactionObserver(self)
        SKPaymentQueue.defaultQueue().restoreCompletedTransactions()
    }

    func buyProduct() {
        println("buy " + p.productIdentifier)
        var pay = SKPayment(product: p)
        SKPaymentQueue.defaultQueue().addTransactionObserver(self)
        SKPaymentQueue.defaultQueue().addPayment(pay as SKPayment)
    }
    
    func productsRequest(request: SKProductsRequest!, didReceiveResponse response: SKProductsResponse!) {
        println("product request")
        var myProduct = response.products
        println(response.products.count)
        
        for product in myProduct {
            println("product added")
            println(product.productIdentifier)
            println(product.localizedTitle)
            println(product.localizedDescription)
            println(product.price)
            
            list.append(product as! SKProduct)
        }
        
        tier1Outlet.enabled = true
        tier2Outlet.enabled = true
        tier3Outlet.enabled = true
        tier4Outlet.enabled = true
    }
    
    func paymentQueueRestoreCompletedTransactionsFinished(queue: SKPaymentQueue!) {
        println("transactions Restored")
        
        var purchasedItemIDs = []
        for transaction in queue.transactions {
            var t: SKPaymentTransaction = transaction as! SKPaymentTransaction
            
            let prodID = t.payment.productIdentifier as String
            
            switch prodID {
            case "com.surpriseindustries.robyn.tier1":
                println("Purchase of tier 1")
                donateBitches()
            case "com.surpriseindustries.robyn.tier2":
                println("Purchase of tier 2")
                donateBitches()
            case "com.surpriseindustries.robyn.tier3":
                println("Purchase of tier 3")
                donateBitches()
            case "com.surpriseindustries.robyn.tier4":
                println("Purchase of tier 4")
                donateBitches()
            default: println("IAP not setup")
            }
        }
    }
    
    func paymentQueue(queue: SKPaymentQueue!, updatedTransactions transactions: [AnyObject]!) {
        println("add payment")
        for transaction:AnyObject in transactions {
            var trans = transaction as! SKPaymentTransaction
            println(trans.error)
            
            switch trans.transactionState {
            case .Purchased:
                println("buy, okay to unlock iap here")
                println(p.productIdentifier)
                
                let prodID = p.productIdentifier as String
                switch prodID {
                case "com.surpriseindustries.robyn.tier1":
                    println("Purchase of tier 1")
                case "com.surpriseindustries.robyn.tier2":
                    println("Purchase of tier 2")
                case "com.surpriseindustries.robyn.tier3":
                    println("Purchase of tier 3")
                case "com.surpriseindustries.robyn.tier4":
                    println("Purchase of tier 4")
                default: println("IAP not setup")
                }
                queue.finishTransaction(trans)
                break
                
            case .Failed:
                println("buy error")
                queue.finishTransaction(trans)
                break
                
            default:
                println("default")
                break
            }
        }
    }
    
    func finishTransaction(trans:SKPaymentTransaction) {
        println("finish trans")
    }
    
    func paymentQueue(queue: SKPaymentQueue!, removedTransactions transactions: [AnyObject]!) {
        println("removed trans")
    }
}
