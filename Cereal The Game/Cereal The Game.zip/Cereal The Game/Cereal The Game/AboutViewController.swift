//
//  AboutViewController.swift
//  Cereal The Game
//
//  Created by Rob Wyant on 3/22/15.
//  Copyright (c) 2015 Rob Wyant. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {
    
    var request: NSURLRequest?
    
    @IBAction func openBrowserAction(sender: AnyObject) {
        UIApplication.sharedApplication().openURL(NSURL(string:"http://surpriseindustries.com")!)
    }
    
    override func viewDidLoad() {
        if let request = self.request {
        }
    }
}
